//
//  ViewController.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-10-27.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    @IBOutlet weak var textfield_Pwd: UITextField!
    @IBOutlet weak var textfield_Email: UITextField!
    
    var email : [String] = ["vishal@gmail.com", "puneet@gmail.com", "guru@gmail.com"]
    var password : [String] = ["12345", "123456", "1234567"]
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.title = "LOGIN"
        self.navigationController!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]
        
        //Getures
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.gestureMethod(_:)))
        view.addGestureRecognizer(tapGesture)
        //End
    }
    
    @objc func gestureMethod(_ sender: UITapGestureRecognizer)
    {
        self.view.endEditing(true)
    }
    
    @IBAction func btn_Login(_ sender: UIButton)
    {
        self.view.endEditing(true)
        if(textfield_Email.text == "")
        {
            let alert = UIAlertController(title: "ToDo", message: "Please enter your Email-Id.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else if(textfield_Pwd.text == "")
        {
            let alert = UIAlertController(title: "ToDo", message: "Please enter your Password.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        else
        {
            for i in 0..<email.count
            {
                if(email[i] == textfield_Email.text)
                {
                    if(password[i] == textfield_Pwd.text && email[i] == textfield_Email.text)
                    {
                        let tabs:UIViewController =  (self.storyboard?.instantiateViewController(withIdentifier: "tabs") as? Tabs)!
                        self.navigationController?.pushViewController(tabs, animated: true)
                    }
                    else
                    {
                        let alert = UIAlertController(title: "ToDo", message: "Invalid Email-Id and Password.", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        }
    }
}
