//
//  Tabs.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-10-27.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation
//
//  FirstView.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-10-27.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation
import UIKit

class Tabs : UITabBarController, UITabBarControllerDelegate
{
    static var flagView : Bool = false

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.title = "HOME"
        self.navigationItem.hidesBackButton = true
        self.navigationController!.navigationBar.titleTextAttributes = [NSAttributedStringKey.foregroundColor: UIColor.white]

        misc()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        Tabs.flagView = false
        LandingDetail.flag = false
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "callForAlert"), object: nil)
    }
    
    override func viewWillDisappear(_ animated: Bool)
    {
        NotificationCenter.default.removeObserver(self)
    }

    func misc()
    {
        //Left bar button item
        let rightBarButton : UIBarButtonItem = UIBarButtonItem(title: "LOGOUT", style: UIBarButtonItemStyle.plain, target: self, action: #selector(addTappedRight))
        rightBarButton.tintColor = UIColor.white
        
        self.navigationItem.rightBarButtonItem = rightBarButton
        //Ends
        
        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "ADD", style: UIBarButtonItemStyle.plain, target: self, action: #selector(addTappedLeft))
        leftButton.tintColor = UIColor.white
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
    }
    
    @objc func addTappedLeft()
    {
        Tabs.flagView = true
        let addnewitemtodo:UIViewController =  (self.storyboard?.instantiateViewController(withIdentifier: "addnewitemtodo") as? AddNewToDoItem)!
        self.navigationController?.pushViewController(addnewitemtodo, animated: true)
    }
    
    @objc func addTappedRight()
    {
        let alertController = UIAlertController(title: "ToDo", message: "Do you really want to logout?", preferredStyle: UIAlertControllerStyle.alert)
        
        alertController.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.destructive) {
            (result : UIAlertAction) -> Void in
            self.navigationController?.popViewController(animated: true)
        })
        alertController.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default))
        
        self.present(alertController, animated: true, completion: nil)
    }
}

