//
//  MapView.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-10-27.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class MapView : UIViewController
{
    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.gray
        self.title = "MAP"
        
        mapMethod()
    }
    
    func mapMethod()
    {
        let locations = [
            ["title": "Missisauga, Canada", "latitude": 43.595310 , "longitude": -79.640579],
            ["title": "Brampton, Canada", "latitude": 43.683334 , "longitude": -79.766670],
            ["title": "Toronto, Canada", "latitude": 43.639217 , "longitude": -79.400414]
        ]
        
        for location in locations
        {
            let annotation = MKPointAnnotation()
            annotation.title = location["title"] as? String
            annotation.coordinate = CLLocationCoordinate2D(latitude: location["latitude"] as! Double, longitude: location["longitude"] as! Double)
            mapView.addAnnotation(annotation)
            
            //To set the zoom level
            let span = MKCoordinateSpanMake(1.0, 1.0)
            let region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: location["latitude"] as! Double, longitude: location["longitude"] as! Double), span: span)
            mapView.setRegion(region, animated: true)
        }
    }
}
