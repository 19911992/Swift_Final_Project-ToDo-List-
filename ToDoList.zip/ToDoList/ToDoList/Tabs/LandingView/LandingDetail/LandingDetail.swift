//
//  LandingDetail.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-11-06.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class LandingDetail: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var tableview_Detail: UITableView!
    
    static var groceryItems : [String] = ["Lentils", "Chips", "Soap", "Colgate"]
    static var billPaymentsItems : [String] = ["Phone", "Electricity"]
    static var passItems : [String] = ["Bus Pass", "Metro Pass"]
    static var newItems : [String] = []
    static var newItems1 : [String] = []
    static var newItems2 : [String] = []
    static var newItems3 : [String] = []

    static var flag : Bool = false
    static var indexValue : NSIndexPath!

    var index : NSIndexPath!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        title = "ITEM DETAIL"
        
        NavigationButton()
        
        tableview_Detail.delegate = self
        tableview_Detail.dataSource = self
        tableview_Detail.backgroundView = UIImageView(image: UIImage(named: "bg"))
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        print("\(LandingDetail.groceryItems.count) \(LandingDetail.billPaymentsItems.count) \(LandingDetail.passItems.count)")
        
        DispatchQueue.main.async{
            self.tableview_Detail.reloadData()
        }
    }
    
    func NavigationButton()
    {
        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "BACK", style: UIBarButtonItemStyle.plain, target: self, action: #selector(addTappedLeft))
        leftButton.tintColor = UIColor.white
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
        
        //Left bar button item
        let rightButton : UIBarButtonItem = UIBarButtonItem(title: "ADD", style: UIBarButtonItemStyle.plain, target: self, action: #selector(addTappedRight))
        rightButton.tintColor = UIColor.white
        
        self.navigationItem.rightBarButtonItem = rightButton
        //Ends
    }
    
    @objc func addTappedLeft()
    {
        LandingDetail.flag = false
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func addTappedRight()
    {
        LandingDetail.flag = true
        LandingDetail.indexValue = index
        let addnewitemtodo:UIViewController =  (self.storyboard?.instantiateViewController(withIdentifier: "addnewitemtodo") as? AddNewToDoItem)!
        self.navigationController?.pushViewController(addnewitemtodo, animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        if(index.row == 0)
        {
            return LandingDetail.groceryItems.count
        }
        else if(index.row == 1)
        {
            return LandingDetail.billPaymentsItems.count
        }
        else if(index.row == 2)
        {
            return LandingDetail.passItems.count
        }
        else if(index.row == 3)
        {
            if(LandingDetail.newItems.count != 0)
            {
                return LandingDetail.newItems.count
            }
            else
            {
                return 1
            }
        }
        else if(index.row == 4)
        {
            if(LandingDetail.newItems1.count != 0)
            {
                return LandingDetail.newItems.count
            }
            else
            {
                return 1
            }
        }
        else if(index.row == 5)
        {
            if(LandingDetail.newItems2.count != 0)
            {
                return LandingDetail.newItems2.count
            }
            else
            {
                return 1
            }
        }
        else
        {
            if(LandingDetail.newItems3.count != 0)
            {
                return LandingDetail.newItems3.count
            }
            else
            {
                return 1
            }
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell_identifier") as! LandingDetailCustomCell
        
        if(index.row == 0)
        {
            cell.label_Item.text = LandingDetail.groceryItems[indexPath.row]
        }
        else if(index.row == 1)
        {
            cell.label_Item.text = LandingDetail.billPaymentsItems[indexPath.row]
        }
        else if(index.row == 2)
        {
            cell.label_Item.text = LandingDetail.passItems[indexPath.row]
        }
        else if(index.row == 3)
        {
            if(LandingDetail.newItems.count != 0)
            {
                cell.label_Item.text = LandingDetail.newItems[indexPath.row]
            }
            else
            {
                cell.label_Item.text = "No items"
            }
        }
        else if(index.row == 4)
        {
            if(LandingDetail.newItems1.count != 0)
            {
                cell.label_Item.text = LandingDetail.newItems1[indexPath.row]
            }
            else
            {
                cell.label_Item.text = "No items"
            }
        }
        else if(index.row == 5)
        {
            if(LandingDetail.newItems2.count != 0)
            {
                cell.label_Item.text = LandingDetail.newItems2[indexPath.row]
            }
            else
            {
                cell.label_Item.text = "No items"
            }
        }
        else if(index.row == 6)
        {
            if(LandingDetail.newItems3.count != 0)
            {
                cell.label_Item.text = LandingDetail.newItems3[indexPath.row]
            }
            else
            {
                cell.label_Item.text = "No items"
            }
        }
    
        cell.backgroundColor = UIColor(white: 1, alpha: 0.5)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if (editingStyle == UITableViewCellEditingStyle.delete)
        {
            if(index.row == 0)
            {
                LandingDetail.groceryItems.remove(at: indexPath.row)
            }
            else if(index.row == 1)
            {
                LandingDetail.billPaymentsItems.remove(at: indexPath.row)
            }
            else if(index.row == 2)
            {
                LandingDetail.passItems.remove(at: indexPath.row)
            }
            else if(index.row == 3)
            {
                LandingDetail.newItems.remove(at: indexPath.row)
            }
            else if(index.row == 4)
            {
                LandingDetail.newItems1.remove(at: indexPath.row)
            }
            else if(index.row == 5)
            {
                LandingDetail.newItems2.remove(at: indexPath.row)
            }
            else if(index.row == 6)
            {
                LandingDetail.newItems3.remove(at: indexPath.row)
            }
            tableView.reloadData()
        }
    }
}
