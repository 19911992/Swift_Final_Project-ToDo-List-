//
//  LandingDetailCustomCell.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-11-06.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class LandingDetailCustomCell: UITableViewCell
{
    @IBOutlet weak var label_Item: UILabel!
    
    override func awakeFromNib()
    {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool)
    {
        super.setSelected(selected, animated: animated)
    }
}
