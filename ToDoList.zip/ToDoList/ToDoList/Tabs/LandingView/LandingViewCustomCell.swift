//
//  LandingViewCustomCell.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-10-27.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation
import UIKit

class LandingViewCustomCell: UITableViewCell
{
    @IBOutlet weak var label_ListItemData: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
