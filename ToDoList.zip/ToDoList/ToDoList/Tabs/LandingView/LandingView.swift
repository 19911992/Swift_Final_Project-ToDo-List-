//
//  LandingView.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-10-27.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation
import UIKit

class LandingView : UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var tableView_Landing: UITableView!
    static var todoItems : [String] = ["Grocery", "Bill Payment", "Bus Pass"]
    var index : NSIndexPath!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.title = "Home"
        
        tableView_Landing.delegate = self
        tableView_Landing.backgroundView = UIImageView(image: UIImage(named: "bg"))
        tableView_Landing.dataSource = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(showAlert), name: NSNotification.Name(rawValue: "callForAlert"), object: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return LandingView.todoItems.count
    }
    
    @objc func showAlert()
    {
        DispatchQueue.main.async{
            self.tableView_Landing.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell_identifier") as! LandingViewCustomCell
        let text = LandingView.todoItems[indexPath.row]
        
        cell.label_ListItemData.text = text
        cell.backgroundColor = UIColor(white: 1, alpha: 0.5)        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        tableView.deselectRow(at: indexPath, animated: true)
        index = indexPath as NSIndexPath

        self.performSegue(withIdentifier: "landingdetail", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?)
    {
        if(segue.identifier == "landingdetail")
        {
            let landingdetail = segue.destination as! LandingDetail
            
            landingdetail.index = index
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if (editingStyle == UITableViewCellEditingStyle.delete)
        {
            LandingView.todoItems.remove(at: indexPath.row)

            if(indexPath.row == 0)
            {
                LandingDetail.groceryItems.removeAll()
            }
            else if(indexPath.row == 1)
            {
                LandingDetail.billPaymentsItems.removeAll()
            }
            else if(indexPath.row == 2)
            {
                LandingDetail.passItems.removeAll()
            }
            else if(indexPath.row == 3)
            {
                LandingDetail.newItems.removeAll()
            }
            else if(indexPath.row == 4)
            {
                LandingDetail.newItems1.removeAll()
            }
            else if(indexPath.row == 5)
            {
                LandingDetail.newItems2.removeAll()
            }
            else if(indexPath.row == 6)
            {
                LandingDetail.newItems3.removeAll()
            }
            
            tableView.reloadData()
        }
    }
}
