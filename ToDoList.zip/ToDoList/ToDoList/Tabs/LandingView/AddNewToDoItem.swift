//
//  AddNewToDoItem.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-11-06.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import UIKit

class AddNewToDoItem: UIViewController
{
    @IBOutlet weak var btn_Save: UIButton!
    @IBOutlet weak var textfield_NewItem: UITextField!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.title = "ADD ITEM"

        //Left bar button item
        let leftButton : UIBarButtonItem = UIBarButtonItem(title: "BACK", style: UIBarButtonItemStyle.plain, target: self, action: #selector(addTappedLeft))
        leftButton.tintColor = UIColor.white
        
        self.navigationItem.leftBarButtonItem = leftButton
        //Ends
        
        //Gestures
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.gestureMethod(_:)))
        view.addGestureRecognizer(tapGesture)
        //End
    }
    
    @objc func addTappedLeft()
    {
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func gestureMethod(_ sender: UITapGestureRecognizer)
    {
        self.view.endEditing(true)
    }
    
    @IBAction func btn_Save(_ sender: UIButton)
    {
        self.view.endEditing(true)
        if(textfield_NewItem.text?.isEmpty == false)
        {
            let alertController = UIAlertController(title: "ToDo", message: "Do you really want to add this new item?", preferredStyle: UIAlertControllerStyle.alert)
            
            alertController.addAction(UIAlertAction(title: "Yes", style: UIAlertActionStyle.destructive) {
                (result : UIAlertAction) -> Void in
                
                if(LandingDetail.flag != true)
                {
                    if(Tabs.flagView == true)
                    {
                        LandingView.todoItems.append(self.textfield_NewItem.text!)
                    }
                    else
                    {
                        LandingDetail.newItems.append(self.textfield_NewItem.text!)
                    }
                }
                else
                {
                    if(LandingDetail.indexValue.row == 0)
                    {
                        LandingDetail.groceryItems.append(self.textfield_NewItem.text!)
                    }
                    else if(LandingDetail.indexValue.row == 1)
                    {
                        LandingDetail.billPaymentsItems.append(self.textfield_NewItem.text!)
                    }
                    else if(LandingDetail.indexValue.row == 2)
                    {
                        LandingDetail.passItems.append(self.textfield_NewItem.text!)
                    }
                    else if(LandingDetail.indexValue.row == 3)
                    {
                        LandingDetail.newItems.append(self.textfield_NewItem.text!)
                    }
                    else if(LandingDetail.indexValue.row == 4)
                    {
                        LandingDetail.newItems1.append(self.textfield_NewItem.text!)
                    }
                    else if(LandingDetail.indexValue.row == 5)
                    {
                        LandingDetail.newItems2.append(self.textfield_NewItem.text!)
                    }
                    else if(LandingDetail.indexValue.row == 6)
                    {
                        LandingDetail.newItems3.append(self.textfield_NewItem.text!)
                    }
                }
                
                self.navigationController?.popViewController(animated: true)
            })
            alertController.addAction(UIAlertAction(title: "No", style: UIAlertActionStyle.default))
            
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            let alert = UIAlertController(title: "ToDo", message: "Please enter item name.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
}
