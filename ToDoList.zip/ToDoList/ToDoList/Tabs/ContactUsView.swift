//
//  ContactUsView.swift
//  ToDoList
//
//  Created by Vishal Verma on 2017-10-27.
//  Copyright © 2017 Vishal Verma. All rights reserved.
//

import Foundation
import UIKit

class ContactUsView : UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.red
        self.title = "CONTACT US"
    }
}
